﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kalkulacka_rovnic
{
    internal class Program
    {
        static void Main(string[] args)
        {

            {
                {
                    Console.WriteLine("Co tu chceš more");

                    Console.Write("hodnota a: ");
                    
                    int a = Convert.ToInt16(Console.ReadLine());
                    
                    Console.Write("hodnota b: ");
                    
                    int b = Convert.ToInt16(Console.ReadLine());
                    
                    Console.Write("hodnota c: ");
                    
                    int c = Convert.ToInt16(Console.ReadLine());
                    
                    double diskriminant=(b*b)-(4*a*c);
                    
                    if(diskriminant>0)
                    {
                        Double x1 = (-b +Math.Sqrt(diskriminant))/(2*a);
                        
                        Double x2 = (-b -Math.Sqrt(diskriminant))/(2*a);
                        
                        Console.WriteLine($"Kvadr. rovnice má 2 reálný kořeny:x1={x1},x2={x2}");
                    }
                    else
                    {
                        Console.WriteLine("nemá řešení");
                    }
                    Console.ReadKey();
                }
            }
        }
    }
}
